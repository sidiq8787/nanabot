import time

from nana import app, Owner, Command
from pyrogram import Filters


@app.on_message(Filters.user(Owner) & Filters.command(["ff"], Command))
async def ping(client, message):
	await message.edit("😂😂😂😂😂😂😂😂\n😂😂😂😂😂😂😂😂\n😂😂😂\n😂😂😂\n😂😂😂😂😂😂😂😂\n😂😂😂😂😂😂😂😂\n😂😂😂\n😂😂😂\n😂😂😂\n😂😂😂\n\n\n😂😂😂😂😂😂😂😂\n😂😂😂😂😂😂😂😂\n😂😂😂\n😂😂😂\n😂😂😂😂😂😂😂😂\n😂😂😂😂😂😂😂😂\n😂😂😂\n😂😂😂\n😂😂😂\n😂😂😂")
