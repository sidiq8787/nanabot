# Buat file config.py baru dalam dir dan impor yang sama, kemudian perpanjang kelas ini.
class Config(object):
	LOGGER = True
	
	# Must be filled!
	# Register here: https://my.telegram.org/apps
	api_id = 824488
	api_hash = "c51e337435409d1175eb996cb81629a3"
	DATABASE_URL = "postgres://nana:ff01filia@localhost:5432/nanadb"
	
	# Version
	lang_code = "id" # Your language code
	device_model = "PC" # Device model
	system_version = "Linux" # OS system type

	# Use real bot for Assistant
	# Pass False if you dont want
	ASSISTANT_BOT = False
	ASSISTANT_BOT_TOKEN = "1025155786:AAGHgrgmVbnZzcKVl1WDZjF65OCLuPO8R_U"

	# Required for some features
	AdminSettings = [956962027] # Insert int id, Add someone so they can access your assistant, leave it blank if you dont want!
	Command = ["!", ".", "/"] # Insert command prefix, if you insert "!" then you can do !ping
	# WORKER must be int (number)
	NANA_WORKER = 8
	ASSISTANT_WORKER = 2
	# If True, send notification to user if Official branch has new update after running bot
	REMINDER_UPDATE = True

	# APIs token
	thumbnail_API = "ab63d0d324c8f21ffcfd97b64455ac8f6808bb577dac" # Register free here: https://thumbnail.ws/
	screenshotlayer_API = "b8f0674e95ffe3fad4083082219cc585" # Register free here: https://screenshotlayer.com/

	# Load or no load plugins
	# userbot
	USERBOT_LOAD = []
	USERBOT_NOLOAD = []
	# manager bot
	ASSISTANT_LOAD = []
	ASSISTANT_NOLOAD = []

	# Fill this if you want to login using session code, else leave it blank
	USERBOT_SESSION = "BQAqQQlqZtyX3B14CcchEJdzHvRfdn1H9sX_fnWibKVsVTtgpoIRQRYvFZ5hk5VmnvkMsU-OacsoLmraUuw05GLDqeOpPkW3sLIYsnEcx6rCCcVobhf7QQI8vAJUzBwXvQzqKWFhIT4_h5TOpMDlY6q-btjbYO7eOljoimgAJD2cnLURUj8SuBgYLDtoY6_N0eoDLEP2Oij9ACpYNVEs61eRDGiXR99xbs2MmcAxaU3B083tiADj6Vy8AOPtbAJjylNp3AqC94kTBY1cB-cEhVXCE4fVjRKfzdzKkromCQXh8MXAu7cC-3fxtXDQ8YGJllqhnQRAUYzsM92kr94iyGaTQFz3MQA"
	ASSISTANT_SESSION = "BQCIsZ2MwsDm7xQJoswge3mt2Y7ICre_LHaOYGkBCiC55n0LPgX5vDs3brZ7amHBt5dBkjnRY2jSPxnrujLMoLVhyTOReK5aA9ykhRrlSsE3kTBt6eWeg0pjqioK3WHkGjJtpBNRu_uT9-oLv3lCYY8s4QW5lETDqx5izv8Nr5acYKt2sVGjwcVy6B-XiSYJrYEPsyqdCZ5X1VlpCN5Mq3NbWcCfyVjW-tmH8kIkGKHtVv5VRArBMO53M0eAlL8L6AV2HIXVdZtlMtHxI9mYmtvY3siwJFvv-mcm57BCgYUvPp18JS_G8XtGLF-HcsNI1QdZzg2OWdAqHJCOdAbbp7KfPRqiygE"

	# Pass True if you want to use test mode
	TEST_MODE = False
	

class Production(Config):
	LOGGER = False


class Development(Config):
	LOGGER = True
