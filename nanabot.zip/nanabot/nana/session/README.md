# Session
What it is?
This place where your session output is.

# WARNING
Do not share any of this file to public or push to git, else someone will hack your account!
